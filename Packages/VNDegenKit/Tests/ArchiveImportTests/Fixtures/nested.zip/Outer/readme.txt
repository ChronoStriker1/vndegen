Extract inner.7z
